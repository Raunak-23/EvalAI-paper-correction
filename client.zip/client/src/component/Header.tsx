import React from "react";
import { Bell, Moon } from "lucide-react";

const Header: React.FC = () => {
  return (
    <header className="w-full bg-white shadow-sm flex justify-between items-center px-6 py-3">
      {/* Left Section: Logo and Title */}
      <div className="flex items-center space-x-3">
        {/* Gradient Circle with Initial */}
        <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold w-10 h-10 rounded-full flex items-center justify-center text-lg shadow-md">
          E
        </div>
        {/* Title and Subtitle */}
        <div className="flex flex-col leading-tight">
          <h1 className="text-lg font-bold text-gray-900">Eval AI</h1>
          <p className="text-xs text-gray-500">AI-Powered Paper Evaluator</p>
        </div>
      </div>

      {/* Right Section: Icons and Profile */}
      <div className="flex items-center space-x-6">
        {/* Theme Toggle */}
        <button className="text-purple-600 hover:text-purple-700">
          <Moon className="w-5 h-5" />
        </button>

        {/* Notification Bell */}
        <button className="relative text-gray-600 hover:text-gray-800">
          <Bell className="w-5 h-5" />
          {/* Red Dot Indicator */}
          <span className="absolute top-0 right-0 block w-2 h-2 bg-red-500 rounded-full"></span>
        </button>

        {/* Profile Avatar */}
        <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white font-semibold w-10 h-10 rounded-full flex items-center justify-center shadow-md">
          D
        </div>
      </div>
    </header>
  );
};

export default Header;
