import React from "react";
import { motion } from "framer-motion";
import {
  BookOpen,
  MessageSquare,
  Send,
  Mail,
  Phone,
} from "lucide-react";

// --- Helper Component: HelpCard ---
// A reusable wrapper for the main content blocks
type HelpCardProps = {
  icon: React.ElementType;
  title: string;
  iconBg: string;
  iconColor: string;
  children: React.ReactNode;
};

const HelpCard: React.FC<HelpCardProps> = ({
  icon: Icon,
  title,
  iconBg,
  iconColor,
  children,
}) => (
  <div className="bg-white p-6 rounded-xl shadow-lg">
    <div className="flex items-center gap-3 mb-5">
      <div className={`p-2 rounded-lg ${iconBg}`}>
        <Icon size={20} className={iconColor} />
      </div>
      <h2 className="text-xl font-semibold text-gray-800">{title}</h2>
    </div>
    {children}
  </div>
);

// --- Main Help Component ---
export default function Help() {
  return (
    <div className="flex flex-col flex-1 p-6 md:p-8 bg-gray-50 min-h-screen">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {/* Header */}
        <h1
          className="text-3xl font-bold"
          style={{ color: "#ae30ff" }} // Purple color from image
        >
          Help
        </h1>
        <p className="text-gray-500 mb-8">
          Get support and learn more about Eval AI
        </p>

        {/* Cards Container */}
        <div className="space-y-6">
          {/* --- User Guides Card --- */}
          <HelpCard
            icon={BookOpen}
            title="User Guides"
            iconBg="bg-purple-100"
            iconColor="text-purple-600"
          >
            <div className="space-y-3">
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-3.5 flex items-center">
                <span className="h-2 w-2 bg-purple-500 rounded-full mr-3 flex-shrink-0"></span>
                <p className="text-sm font-medium text-gray-700 cursor-pointer hover:text-purple-600">
                  How to add a new class
                </p>
              </div>
              <div className="bg-white border border-gray-200 rounded-lg p-3.5 flex items-center">
                <span className="h-2 w-2 bg-purple-500 rounded-full mr-3 flex-shrink-0"></span>
                <p className="text-sm font-medium text-gray-700 cursor-pointer hover:text-purple-600">
                  Difference between Bulk Upload and Single File Upload
                </p>
              </div>
              <div className="bg-white border border-gray-200 rounded-lg p-3.5 flex items-center">
                <span className="h-2 w-2 bg-purple-500 rounded-full mr-3 flex-shrink-0"></span>
                <p className="text-sm font-medium text-gray-700 cursor-pointer hover:text-purple-600">
                  Difference between the models offered
                </p>
              </div>
            </div>
          </HelpCard>

          {/* --- Contact Support Card --- */}
          <HelpCard
            icon={MessageSquare}
            title="Contact Support"
            iconBg="bg-blue-100"
            iconColor="text-blue-600"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Email */}
              <div
                className="p-4 rounded-lg flex items-center gap-4"
                style={{ backgroundColor: "#f5f9ff" }} // Light blue
              >
                <div className="bg-white p-2.5 rounded-full shadow-sm">
                  <Mail size={20} className="text-blue-600" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-800">Email</p>
                  <p className="text-sm text-gray-600">evalai@gmail.com</p>
                </div>
              </div>
              {/* Phone */}
              <div
                className="p-4 rounded-lg flex items-center gap-4"
                style={{ backgroundColor: "#f8f5ff" }} // Light purple
              >
                <div className="bg-white p-2.5 rounded-full shadow-sm">
                  <Phone size={20} className="text-purple-600" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-800">
                    Toll free
                  </p>
                  <p className="text-sm text-gray-600">1800-123-4567</p>
                </div>
              </div>
            </div>
          </HelpCard>

          {/* --- Report a Bug Card --- */}
          <HelpCard
            icon={Send}
            title="Report a Bug"
            iconBg="bg-red-100"
            iconColor="text-red-600"
          >
            <form>
              <textarea
                placeholder="Describe the issue you're experiencing..."
                className="w-full p-3 min-h-[120px] bg-white border border-gray-200 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
              ></textarea>
              <button
                type="submit"
                className="mt-4 flex items-center justify-center gap-2 px-5 py-2.5 bg-gradient-to-r from-purple-600 to-blue-500 text-white font-semibold rounded-lg shadow-md hover:opacity-90 transition-opacity"
              >
                <Send size={16} />
                Submit Report
              </button>
            </form>
          </HelpCard>
        </div>
      </motion.div>
    </div>
  );
}