import React from "react";
import { motion } from "framer-motion";
import { Save } from "lucide-react";

// --- Helper Component: FormSelect ---
// A reusable component for the styled select boxes
type FormSelectProps = React.SelectHTMLAttributes<HTMLSelectElement> & {
  label: string;
  id: string;
  children: React.ReactNode;
};

const FormSelect: React.FC<FormSelectProps> = ({
  label,
  id,
  children,
  ...props
}) => (
  <div>
    <label
      htmlFor={id}
      className="block text-sm font-semibold text-gray-700 mb-2"
    >
      {label}
    </label>
    <select
      id={id}
      {...props}
      className="block w-full p-3 bg-white border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
    >
      {children}
    </select>
  </div>
);

// --- Main Grading Component ---
export default function Grading() {
  return (
    <div className="flex flex-col flex-1 p-6 md:p-8 bg-gray-50 min-h-screen">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {/* Header */}
        <h1
          className="text-3xl font-bold"
          style={{ color: "#ae30ff" }} // Purple color from image
        >
          Grading
        </h1>
        <p className="text-gray-500 mb-8">
          Review and adjust AI-generated scores
        </p>

        {/* Top Selectors */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <FormSelect label="Select Class" id="class-select">
            <option>CSI3001 - Data Science (G1+TG1)</option>
            <option>CSE1001 - Intro to Programming</option>
          </FormSelect>
          <FormSelect label="Select Student" id="student-select">
            <option>23MID999</option>
            <option>23MID100</option>
          </FormSelect>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column: Preview */}
          <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-lg">
            <h2 className="text-xl font-semibold mb-4 text-gray-800">
              Preview
            </h2>
            <div className="flex items-center justify-center min-h-[70vh] bg-gray-100 rounded-lg border border-gray-200">
              <p className="text-gray-500 font-medium">Answer Sheet Preview</p>
            </div>
          </div>

          {/* Right Column: Grading Tools */}
          <div className="lg:col-span-1 space-y-6">
            {/* Question Selector */}
            <div className="bg-white p-5 rounded-xl shadow-lg flex items-center justify-between">
              <label
                htmlFor="question-select"
                className="font-semibold text-gray-800"
              >
                Question -
              </label>
              <select
                id="question-select"
                className="p-2 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500"
              >
                <option>Q1</option>
                <option selected>Q2</option>
                <option>Q3</option>
              </select>
            </div>

            {/* AI Score Card */}
            <div className="bg-green-50 border border-green-200 p-5 rounded-xl shadow-sm">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm font-medium text-green-800">
                    AI suggested Score
                  </p>
                  <p className="text-4xl font-bold text-gray-900 my-1">8/10</p>
                  <p className="text-xs text-gray-600">Confidence</p>
                </div>
                <div className="text-xl font-bold text-green-600">91%</div>
              </div>
            </div>

            {/* Adjust Marks */}
            <div>
              <label
                htmlFor="adjust-marks"
                className="block text-sm font-semibold text-gray-700 mb-2"
              >
                Adjust Marks
              </label>
              <input
                type="number"
                id="adjust-marks"
                defaultValue="9"
                className="w-full p-3 bg-white border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            {/* AI Feedback */}
            <div>
              <label
                htmlFor="ai-feedback"
                className="block text-sm font-semibold text-gray-700 mb-2"
              >
                AI Feedback
              </label>
              <textarea
                id="ai-feedback"
                rows={4}
                className="w-full p-3 bg-white border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                defaultValue="The student has good understanding of cloud models and demonstrated clear knowledge of deployment strategies..."
              />
            </div>

            {/* Save Button */}
            <button className="w-full flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-purple-600 to-blue-500 text-white font-semibold rounded-lg shadow-md hover:opacity-90 transition-opacity">
              <Save size={18} />
              Save
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}