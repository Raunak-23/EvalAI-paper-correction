import React, { useState } from "react";
import { motion } from "framer-motion";
import { User, Bot, Bell, Pencil, Camera } from "lucide-react";

// --- Type Definitions ---
type TabKey = "account" | "model" | "notifications";
type ModelKey = "typed" | "handwriting";

// --- Helper Component: TabButton ---
type TabButtonProps = {
  label: string;
  icon: React.ElementType;
  isActive: boolean;
  onClick: () => void;
};

const TabButton: React.FC<TabButtonProps> = ({
  label,
  icon: Icon,
  isActive,
  onClick,
}) => (
  <button
    onClick={onClick}
    className={`flex items-center justify-center gap-2 rounded-md py-2 px-4 text-sm font-semibold transition-all ${
      isActive
        ? "bg-purple-600 text-white shadow-md"
        : "text-gray-600 hover:bg-gray-100"
    }`}
  >
    <Icon size={16} />
    {label}
  </button>
);

// --- Helper Component: SettingsInput ---
type SettingsInputProps = React.InputHTMLAttributes<HTMLInputElement> & {
  label: string;
  id: string;
};

const SettingsInput: React.FC<SettingsInputProps> = ({
  label,
  id,
  ...props
}) => (
  <div>
    <label
      htmlFor={id}
      className="block text-sm font-medium text-gray-700 mb-1"
    >
      {label}
    </label>
    <div className="relative">
      <input
        id={id}
        {...props}
        className="w-full p-3 pr-10 bg-white border border-gray-200 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
      />
      {props.type !== "password" && (
        <Pencil
          size={16}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 cursor-pointer"
        />
      )}
    </div>
  </div>
);

// --- Helper Component: ToggleSwitch ---
type ToggleSwitchProps = {
  enabled: boolean;
  setEnabled: (enabled: boolean) => void;
};

const ToggleSwitch: React.FC<ToggleSwitchProps> = ({ enabled, setEnabled }) => (
  <button
    type="button"
    role="switch"
    aria-checked={enabled}
    onClick={() => setEnabled(!enabled)}
    className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 ${
      enabled ? "bg-purple-600" : "bg-gray-200"
    }`}
  >
    <span
      aria-hidden="true"
      className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
        enabled ? "translate-x-5" : "translate-x-0"
      }`}
    />
  </button>
);

// --- Main Settings Page Component ---
export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState<TabKey>("account");
  const [model, setModel] = useState<ModelKey>("typed");
  const [notifs, setNotifs] = useState({
    login: true,
    completion: true,
    reminders: true,
  });

  return (
    <div className="flex flex-col flex-1 p-6 md:p-8 bg-gray-50 min-h-screen">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {/* Header */}
        <h1
          className="text-3xl font-bold"
          style={{ color: "#ae30ff" }} // Purple color from image
        >
          Settings
        </h1>
        <p className="text-gray-500 mb-6">Manage your account and preferences</p>

        {/* Tab Navigation */}
        <div className="bg-white rounded-full p-1.5 inline-flex gap-1 mb-8 shadow-sm border border-gray-200">
          <TabButton
            label="Account Settings"
            icon={User}
            isActive={activeTab === "account"}
            onClick={() => setActiveTab("account")}
          />
          <TabButton
            label="Model Settings"
            icon={Bot}
            isActive={activeTab === "model"}
            onClick={() => setActiveTab("model")}
          />
          <TabButton
            label="Notifications"
            icon={Bell}
            isActive={activeTab === "notifications"}
            onClick={() => setActiveTab("notifications")}
          />
        </div>

        {/* Main Content Card */}
        <div className="bg-white rounded-xl shadow-lg p-6 md:p-8">
          {/* --- Account Settings Tab --- */}
          {activeTab === "account" && (
            <div className="max-w-4xl mx-auto">
              <div className="flex items-center gap-6 mb-8">
                <div className="w-24 h-24 rounded-full bg-gradient-to-br from-purple-400 to-pink-500 flex items-center justify-center text-white text-4xl font-medium">
                  D
                </div>
                <button className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-800 font-semibold rounded-lg shadow-sm hover:bg-gray-200 transition-colors">
                  <Camera size={18} />
                  Change Photo
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <SettingsInput
                  label="Name"
                  id="name"
                  type="text"
                  defaultValue="Dhivya C R"
                />
                <SettingsInput
                  label="Employee ID"
                  id="employee-id"
                  type="text"
                  defaultValue="EMP12345"
                />
                <SettingsInput
                  label="Email ID"
                  id="email"
                  type="email"
                  defaultValue="dhivya.cr@vitteacher.ac.in"
                  className="md:col-span-2"
                />
                <SettingsInput
                  label="Username"
                  id="username"
                  type="text"
                  defaultValue="Dhivya C R"
                />
                <SettingsInput
                  label="Password"
                  id="password"
                  type="password"
                  defaultValue="••••••••"
                />
              </div>
            </div>
          )}

          {/* --- Model Settings Tab --- */}
          {activeTab === "model" && (
            <div>
              <h3 className="text-lg font-semibold text-gray-800 mb-4">
                Evaluation Model
              </h3>
              <div className="bg-gray-100 rounded-full p-1.5 flex max-w-sm">
                <button
                  onClick={() => setModel("typed")}
                  className={`flex-1 py-2 px-4 rounded-full text-sm font-semibold transition-all ${
                    model === "typed"
                      ? "bg-gradient-to-r from-purple-500 to-blue-500 text-white shadow-lg"
                      : "text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  Typed Text
                </button>
                <button
                  onClick={() => setModel("handwriting")}
                  className={`flex-1 py-2 px-4 rounded-full text-sm font-semibold transition-all ${
                    model === "handwriting"
                      ? "bg-gradient-to-r from-purple-500 to-blue-500 text-white shadow-lg"
                      : "text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  Handwriting
                </button>
              </div>
            </div>
          )}

          {/* --- Notifications Tab --- */}
          {activeTab === "notifications" && (
            <div className="max-w-2xl space-y-4">
              {/* Item 1 */}
              <div className="flex items-center justify-between p-4 bg-white border border-gray-100 rounded-lg shadow-sm">
                <div>
                  <p className="font-semibold text-gray-800">Account Login</p>
                  <p className="text-sm text-gray-500">
                    Get notified on new login attempts
                  </p>
                </div>
                <ToggleSwitch
                  enabled={notifs.login}
                  setEnabled={(val) => setNotifs({ ...notifs, login: val })}
                />
              </div>
              {/* Item 2 */}
              <div className="flex items-center justify-between p-4 bg-white border border-gray-100 rounded-lg shadow-sm">
                <div>
                  <p className="font-semibold text-gray-800">
                    Processing Completion
                  </p>
                  <p className="text-sm text-gray-500">
                    Alert when grading is complete
                  </p>
                </div>
                <ToggleSwitch
                  enabled={notifs.completion}
                  setEnabled={(val) =>
                    setNotifs({ ...notifs, completion: val })
                  }
                />
              </div>
              {/* Item 3 */}
              <div className="flex items-center justify-between p-4 bg-white border border-gray-100 rounded-lg shadow-sm">
                <div>
                  <p className="font-semibold text-gray-800">
                    Upcoming Assignments
                  </p>
                  <p className="text-sm text-gray-500">
                    Reminders for upcoming deadlines
                  </p>
                </div>
                <ToggleSwitch
                  enabled={notifs.reminders}
                  setEnabled={(val) =>
                    setNotifs({ ...notifs, reminders: val })
                  }
                />
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}