import React from "react";
import { motion } from "framer-motion";
import {
  CheckCircle2,
  Clock,
  Users,
  TrendingUp,
  TrendingDown,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react";

// --- Helper Component: StatCard ---
// For the top 3 cards: "Exams graded", "Pending Reviews", "Total Students"
type StatCardProps = {
  title: string;
  value: string;
  trend: "up" | "down";
  percentage: string;
  icon: React.ReactNode;
  iconBgColor: string;
};

const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  trend,
  percentage,
  icon,
  iconBgColor,
}) => {
  const isTrendUp = trend === "up";
  const trendColor = isTrendUp ? "text-green-600" : "text-red-600";
  const TrendIcon = isTrendUp ? TrendingUp : TrendingDown;

  return (
    <div className="bg-white p-5 rounded-xl shadow-lg flex items-center justify-between">
      <div>
        <p className="text-sm font-medium text-gray-500">{title}</p>
        <p className="text-3xl font-bold text-gray-900 my-1">{value}</p>
        <div className={`flex items-center text-sm font-medium ${trendColor}`}>
          <TrendIcon size={16} className="mr-1" />
          {percentage}
        </div>
      </div>
      <div className={`p-4 rounded-lg ${iconBgColor}`}>{icon}</div>
    </div>
  );
};

// --- Helper Component: StatusBadge ---
// For tags like "Completed", "Pending", "Processing"
type StatusBadgeProps = {
  status: "Completed" | "Processing" | "Pending" | "Upcoming";
};

const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => {
  const styles = {
    Completed: "bg-green-100 text-green-700",
    Processing: "bg-yellow-100 text-yellow-700",
    Pending: "bg-red-100 text-red-700",
    Upcoming: "bg-blue-100 text-blue-700",
  };
  const style = styles[status] || "bg-gray-100 text-gray-700";

  return (
    <span
      className={`px-3 py-1 rounded-full text-xs font-semibold ${style}`}
    >
      {status}
    </span>
  );
};

// --- Main Dashboard Component ---
const Dashboard: React.FC = () => {
  // Data modeled after your image
  const statCards = [
    {
      title: "Exams graded",
      value: "37",
      trend: "up" as "up",
      percentage: "+12%",
      icon: <CheckCircle2 size={24} className="text-green-600" />,
      iconBgColor: "bg-green-100",
    },
    {
      title: "Pending Reviews",
      value: "16",
      trend: "down" as "down",
      percentage: "-8%",
      icon: <Clock size={24} className="text-orange-600" />,
      iconBgColor: "bg-orange-100",
    },
    {
      title: "Total Students",
      value: "378",
      trend: "up" as "up",
      percentage: "+12%",
      icon: <Users size={24} className="text-blue-600" />,
      iconBgColor: "bg-blue-100",
    },
  ];

  const recentActivity = [
    {
      id: 1,
      title: "CSI 3001 - CAT 1",
      subtitle: "70 students • 10 days ago",
      status: "Completed" as "Completed",
    },
    {
      id: 2,
      title: "CSI 3001 - Quiz",
      subtitle: "70 students • 2 days ago",
      status: "Processing" as "Processing",
    },
  ];

  const upcoming = [
    {
      id: 1,
      title: "CSI 3001 - Quiz II",
      students: "70 students",
      dueDate: "Due: Sep 15, 2025",
      status: "Pending" as "Pending",
    },
    {
      id: 2,
      title: "CSI 3001 - CAT 2",
      students: "70 students",
      dueDate: null,
      status: "Upcoming" as "Upcoming",
    },
  ];

  return (
    <div className="flex flex-col flex-1 p-6 md:p-8 bg-gray-50 min-h-screen">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {/* Header */}
        <h1
          className="text-3xl font-bold"
          style={{ color: "#ae30ff" }} // Purple color from image
        >
          Welcome back
        </h1>
        <p className="text-gray-500 mb-6">Let's see what is happening in there</p>

        {/* Stat Cards Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
          {statCards.map((card) => (
            <StatCard
              key={card.title}
              title={card.title}
              value={card.value}
              trend={card.trend}
              percentage={card.percentage}
              icon={card.icon}
              iconBgColor={card.iconBgColor}
            />
          ))}
        </div>

        {/* Main Content Area */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Activity Card */}
          <div className="bg-white p-6 rounded-xl shadow-lg">
            <h2 className="text-xl font-semibold mb-4 text-gray-800">
              Recent Activity
            </h2>
            <div className="space-y-4">
              {recentActivity.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between p-4 rounded-lg bg-gray-50"
                >
                  <div>
                    <p className="font-semibold text-gray-700">{item.title}</p>
                    <p className="text-sm text-gray-500">{item.subtitle}</p>
                  </div>
                  <StatusBadge status={item.status} />
                </div>
              ))}
            </div>
          </div>

          {/* Upcoming Card */}
          <div className="bg-white p-6 rounded-xl shadow-lg">
            <h2 className="text-xl font-semibold mb-4 text-gray-800">
              Upcoming
            </h2>
            <div className="space-y-2">
              {upcoming.map((item) => (
                <div
                  key={item.id}
                  className="flex items-start justify-between p-4 border-b border-gray-100 last:border-b-0"
                >
                  <div>
                    <p className="font-semibold text-gray-700">{item.title}</p>
                    {item.dueDate && (
                      <p className="text-sm text-red-500 font-medium">
                        {item.dueDate}
                      </p>
                    )}
                    <p className="text-sm text-gray-500">{item.students}</p>
                  </div>
                  <StatusBadge status={item.status} />
                </div>
              ))}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default Dashboard;