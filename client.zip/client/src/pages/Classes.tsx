import React, { useState } from "react";
import { motion } from "framer-motion";
import { Plus, ClipboardList, BarChart3 } from "lucide-react";

// --- Helper Component: StatusBadge ---
// Re-using the badge from the Dashboard for "Completed", "Pending", etc.
type StatusBadgeProps = {
  status: "Completed" | "Processing" | "Pending" | "Upcoming";
};

const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => {
  const styles = {
    Completed: "bg-green-100 text-green-700",
    Processing: "bg-yellow-100 text-yellow-700",
    Pending: "bg-red-100 text-red-700",
    Upcoming: "bg-blue-100 text-blue-700",
  };
  const style = styles[status] || "bg-gray-100 text-gray-700";

  return (
    <span
      className={`px-3 py-1 rounded-full text-xs font-semibold ${style}`}
    >
      {status}
    </span>
  );
};

// --- Main Classes Component ---
export default function Analytics() {
  const [activeTab, setActiveTab] = useState("assignments");

  // Mock data based on your image
  const assignments = [
    {
      id: 1,
      title: "CSI 3001 - CAT 1",
      details: "70 students • 10 days ago",
      status: "Completed" as "Completed",
    },
    {
      id: 2,
      title: "CSI 3001 - Quiz II",
      details: "70 students • 2 days ago",
      status: "Pending" as "Pending",
    },
    {
      id: 3,
      title: "CSI 3001 - CAT 2",
      details: "70 students • Oct 5, 2025",
      status: "Upcoming" as "Upcoming",
    },
  ];

  return (
    <div className="flex flex-col flex-1 p-6 md:p-8 bg-gray-50 min-h-screen">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <div>
            <h1
              className="text-3xl font-bold"
              style={{ color: "#ae30ff" }} // Purple color from image
            >
              Classes
            </h1>
            <p className="text-gray-500">
              All active classes and assignments
            </p>
          </div>
          <button className="mt-4 md:mt-0 flex items-center justify-center gap-2 px-4 py-2 bg-purple-600 text-white font-semibold rounded-lg shadow-sm hover:bg-purple-700 transition-colors">
            <Plus size={18} />
            Add Class
          </button>
        </div>

        {/* Class Selector */}
        <div className="mb-6">
          <label
            htmlFor="class-select"
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            Select Class:
          </label>
          <select
            id="class-select"
            className="block w-full md:w-auto md:min-w-[300px] p-2 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500"
          >
            <option>CSI3001 - Data Science (G1+TG1)</option>
            <option>CSE1001 - Intro to Programming</option>
          </select>
        </div>

        {/* Class Info Card */}
        <div className="bg-white p-6 rounded-xl shadow-lg mb-6">
          <h2 className="text-2xl font-bold text-gray-900">
            CSI3001 - Data Science
          </h2>
          <p className="text-gray-500">68 students • Slot - G1 + TG1</p>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-200 mb-6">
          <button
            onClick={() => setActiveTab("assignments")}
            className={`flex items-center gap-2 py-3 px-4 text-sm font-semibold ${
              activeTab === "assignments"
                ? "border-b-2 border-purple-600 text-purple-600"
                : "text-gray-500 hover:text-gray-700"
            }`}
          >
            <ClipboardList size={16} />
            Assignments
          </button>
          <button
            onClick={() => setActiveTab("analytics")}
            className={`flex items-center gap-2 py-3 px-4 text-sm font-semibold ${
              activeTab === "analytics"
                ? "border-b-2 border-purple-600 text-purple-600"
                : "text-gray-500 hover:text-gray-700"
            }`}
          >
            <BarChart3 size={16} />
            Analytics
          </button>
        </div>

        {/* Tab Content */}
        <div>
          {/* Assignments List */}
          {activeTab === "assignments" && (
            <div className="space-y-4">
              {assignments.map((item) => (
                <div
                  key={item.id}
                  className="bg-white p-5 rounded-xl shadow-lg flex items-center justify-between"
                >
                  <div>
                    <p className="font-semibold text-gray-800">{item.title}</p>
                    <p className="text-sm text-gray-500">{item.details}</p>
                  </div>
                  <StatusBadge status={item.status} />
                </div>
              ))}
            </div>
          )}

          {/* Analytics Placeholder */}
          {activeTab === "analytics" && (
            <div className="bg-white p-6 rounded-xl shadow-lg">
              <h3 className="text-lg font-semibold text-gray-800 mb-2">
                Class Analytics
              </h3>
              <p className="text-gray-600">
                This is where analytics and performance breakdown for
                CSI3001 - Data Science will be displayed.
              </p>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}